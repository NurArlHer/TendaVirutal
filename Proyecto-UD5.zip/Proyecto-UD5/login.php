<!-- Este PHP se encarca de comprobar el incio de sesión -->
<?php
    // Datos de la conexión al servidor
    $servername = "localhost";
    $username = "ciclom";
    $password = "ciclom";
    $dbname = "smartoffice";
    // Crea la conexión
    $conn = mysqli_connect($servername, $username, $password, $dbname);
    // Comprueba la conexión
    if (!$conn) {
        // Si no se ha establecido correctamente la conexión te muestra el mensaje de error y  mata la conexión
        die("Conexión fallida: " . mysqli_connect_error());
    } 
    // Inicia la sesión para mantener los datos de la sesión del cliente
    session_start();
    // Verificar si el método de envio del formulario es POST
    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        // Recibe los datos del formulario HTM y las almacena en variables
        $email = $_POST["email"];
        $password = $_POST["password"];
        // Prepara una sentencia para extraer los valores del usuario cuyo email coincida con el introducido
        $stmt_verificar = $conn->prepare("SELECT id, email, contrasenya FROM usuarios WHERE email = ?");
        // Establece que el valor de ? es $email
        $stmt_verificar->bind_param("s", $email);
        // Ejecuta la consulta
        $stmt_verificar->execute();
        // Almacena los resultados
        $stmt_verificar->store_result();
        // Comprueba que haya resultados
        if ($stmt_verificar->num_rows > 0) {
            // Si los hay quiere decir que el usuario ya exite
            // Prepara para obtener los resultados y almacenarlos en variables
            $stmt_verificar->bind_result($id, $email, $contrasenya);
            // Obtiene los resultados
            $stmt_verificar->fetch();
            // Verifica las credenciales, es decir si la contraseña coincide con la de la base de datos
            if ($password === $contrasenya) {
                // Inicia la sesión y redirige a la página de inicio
                // Almacena el id del cliente en la sesión
                $_SESSION["id_cliente"] = $id;
                header("Location: inicio.php");
            } else {
                // La contraseña no coincide
                // Crea un mensaje de error
            $error_message = "Usuario o contraseña incorrectos";
            }
        } else {
            // El usuario no existe
            // Crea un mensaje de error
            $error_message = 'El usuario no exite, puede registrarse haciendo click en el siguiente botón <br><a href="registro.html" class="boton-registro">Ir a Registro</a>';
        }
    }
?>


<!-- Inicio del HTML en caso de error -->
<!DOCTYPE html>
<!-- Indica en la etiqueta html que el idioma es español -->
<html lang="es">
<head>
    <!-- Se indican los datos relevantes del estilo y metadatos de la página -->
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- Título de la página -->
    <title>Error de Inicio de Sesión</title>
    <!-- Referencia del CSS con los estilos que sigue la página -->
    <link rel="stylesheet" href="style.css">
</head>
<!-- Aquí comienza el contenido de la página -->
<body>
    <!-- Header con el lema de la empresa y el logo -->
    <header>
        <div style="float: left;margin-left: 33%;">
            <h1 >Alquiler de Oficinas Flexibles</h1>
            <p>Encuentra tu espacio ideal</p>
        </div>
        <div style="float: right;margin-right: 20%;">
            <img src="logo2.png" alt="Logo">
        </div>    
    </header>
    <!-- Navegador que lleva a las otras páginas de la web -->
    <nav>
        <!-- Estos links quedarán alineados a la izquierda del navegador -->
        <div class="nav-left">
            <a href="index.html">Inicio</a> <!-- lleva a # porque es esta misma página -->
            <a href="registro.html">Registro</a>
            <a href="consultas.php">Consultas</a>
            <a href="inicio_sesion.html">Inicio de Sesión</a>
            <a href="encuesta.html">Encuesta Satisfacción</a>
        </div>
        <!-- Estos links quedarán alineados a la derecha del navegador -->
        <div class="nav-right">
            <a href="login_admin.php"><img src="settings.png" alt="Settings" style="max-width: 20px;"></a>
        </div>
    </nav>
    <!-- Contenido principal de la página -->
    <main>
        <!-- Sección que avisa del error producido durante el inicio de sesión -->
        <div class="aviso">
            <h2>Error de Inicio de Sesión</h2>
            <!-- PHP que se encarga de comprobar si existe el mensaje de error que definimos en el PHP anterior -->
            <?php if (isset($error_message)) : ?>
                <!-- Muestra el mensaje de error -->
                <p><?php echo $error_message; ?></p>
            <?php endif; ?>
            <!-- Enlace que lleva a Incio de sesión otra vez -->
                <p><a href="inicio_sesion.html" class="boton-registro">Volver al inicio de sesión</a></p>
        </div>
    </main>
    <!-- Footer con el copyright de la empresa -->
    <footer>
        <p>&copy; 2023 SmartOffice Rent</p>
    </footer>
</body>
</html>