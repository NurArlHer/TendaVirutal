<!-- Este PHP se encarga de realizar una consulta de las tablas pagos y reservas de la bbdd -->
<?php
    // Inicia la sesión si no está iniciada para mantener los datos de la sesión del admin
    session_start();

    // Verifica que el usuario ha iniciado sesión como administrador
    if (!isset($_SESSION["admin"]) || !$_SESSION["admin"]) {
        // Si no es así lo redirige a login_admin.php
        header("Location: login_admin.php");
        exit();
    }

    // Primero ha de realizar la conexión a la base de datos
    // Datos de la conexión al servidor
    $servername = "localhost";
    $username = "ciclom";
    $password = "ciclom";
    $dbname = "smartoffice";

    // Realiza la conexión
    $conn = mysqli_connect($servername, $username, $password, $dbname);

    // Comprueba la conexión
    if (!$conn) {
        // Si no se ha establecido correctamente la conexión te muestra el mensaje de error y  mata la conexión
        die("Conexión fallida: " . mysqli_connect_error());
    }

    // Crea la consulta sobre la tabla reservas con la condición que el id no esté en pagos
    // puesto que eso significaría que ya se ha pagado la reserva
    $sql = "SELECT id, id_cliente, id_oficina, fecha, hora_ini, hora_fin, tipo, total 
            FROM reservas
            WHERE id NOT IN (SELECT id_reserva FROM pagos);";

    // Ejecuta la consulta y almacena los resultados 
    $result = mysqli_query($conn, $sql);

    // Cierra la conexión
    mysqli_close($conn);
?>

<!-- Inicio del HTML -->
<!DOCTYPE html>
<!-- Indica en la etiqueta html que el idioma es español -->
<html lang="es">
<head>
    <!-- Se indican los datos relevantes del estilo y metadatos de la página -->
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- Título de la página -->
    <title>Ver Pagos Pendientes</title>
    <!-- Referencia del CSS con los estilos que sigue la página -->
    <link rel="stylesheet" href="style.css">
</head>
<!-- Aquí comienza el contenido de la página -->
<body>
    <!-- Header con el lema de la empresa y el logo -->
    <header>
        <div style="float: left;margin-left: 33%;">
            <h1 >Alquiler de Oficinas Flexibles</h1>
            <p>Encuentra tu espacio ideal</p>
        </div>
        <div style="float: right;margin-right: 20%;">
            <img src="logo2.png" alt="Logo">
        </div>
    </header>
    <!-- Navegador que lleva a las otras páginas de la web -->
    <nav>
        <!-- Estos links quedarán alineados a la izquierda del navegador -->
        <div class="nav-left">
            <a href="index.html">Inicio</a>
            <a href="registro.html">Registro</a>
            <a href="consultas.php">Consultas</a>
            <a href="inicio_sesion.html">Inicio de Sesión</a>
            <a href="encuesta.html">Encuesta Satisfacción</a>
        </div>
        <!-- Estos links quedarán alineados a la derecha del navegador -->
        <div class="nav-right">
            <a href="login_admin.php"><img src="settings.png" alt="Settings" style="max-width: 20px;"></a>
        </div>
    </nav>
    <main>
        <!-- Título de la consulta -->
        <h2 style="color:#333;">Ver Reservas Pendientes de Pago</h2>
        <!-- Este PHP se encarga de imprimir los resultados de la consulta en forma de tabla -->
        <?php
            // Verifica que la consulta tenga resultados resultados
            if (mysqli_num_rows($result) > 0) {
                // Crea la cabecera de la tabla
                echo "<table>";
                echo "<tr>
                        <th>ID</th>
                        <th>ID Cliente</th>
                        <th>ID Oficina</th>
                        <th>Fecha</th>
                        <th>Hora Inicio</th>
                        <th>Hora Fin</th>
                        <th>Tipo</th>
                        <th>Total</th>
                    </tr>";
                // Imprime los resultados en filas de la tabla
                while ($row = mysqli_fetch_assoc($result)) {
                    echo "<tr>
                            <td>{$row['id']}</td>
                            <td>{$row['id_cliente']}</td>
                            <td>{$row['id_oficina']}</td>
                            <td>{$row['fecha']}</td>
                            <td>{$row['hora_ini']}</td>
                            <td>{$row['hora_fin']}</td>
                            <td>{$row['tipo']}</td>
                            <td>{$row['total']}</td>
                        </tr>";
                }

                echo "</table>";
            } else {
                // En el caso de que no hubiesen resultados muestra un mensaje donde indica que no hay pagos pendientes
                echo "No hay pagos pendientes.";
            }
        ?>
        <!-- Botón que tira hacia atrás al panel de administrador sin cerrar o modificar la sesión -->
        <button class="back-button" onclick="goBack()">Atrás</button> <!-- Al hacer click ejecutará la función mencionada -->
        <!-- Aquí se describe la función que realiza el botón al hacer click en él -->
        <script>
            function goBack() {
                window.history.back(); // Mira el historial de la ventana y tira hacia detrás
            }
        </script>
    </main>
    <!-- Footer con el copyright de la empresa -->
    <footer>
        <p>&copy; 2023 SmartOffice Rent</p>
    </footer>
</body>
</html>