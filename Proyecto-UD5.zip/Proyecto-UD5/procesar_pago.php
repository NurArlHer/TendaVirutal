<!-- Inicio del HTML -->
<!DOCTYPE html>
<!-- Indica en la etiqueta html que el idioma es español -->
<html lang="es">
<head>
    <!-- Se indican los datos relevantes del estilo y metadatos de la página -->
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- Título de la página -->
    <title>Procesamiento de Pagos</title>
    <!-- Referencia del CSS con los estilos que sigue la página -->
    <link rel="stylesheet" href="style.css">
</head>
<!-- Aquí comienza el contenido de la página -->
<body>
    <!-- Header con el lema de la empresa y el logo -->
    <header>
        <div style="float: left;margin-left: 33%;">
            <h1 >Alquiler de Oficinas Flexibles</h1>
            <p>Encuentra tu espacio ideal</p>
        </div>
        <div style="float: right;margin-right: 15%;">
            <img src="logo2.png" alt="Logo">
        </div>
    </header>
    <!-- Navegador que lleva a las otras páginas de la web -->
    <nav>
        <!-- Estos links quedarán alineados a la izquierda del navegador -->
        <div class="nav-left">
            <a href="index.html">Inicio</a> 
            <a href="registro.html">Registro</a>
            <a href="consultas.php">Consultas</a>
            <a href="inicio_sesion.html">Inicio de Sesión</a>
            <a href="encuesta.html">Encuesta Satisfacción</a>
        </div>
        <!-- Estos links quedarán alineados a la derecha del navegador -->
        <div class="nav-right">
            <a href="login_admin.php"><img src="settings.png" alt="Settings" style="max-width: 20px;"></a>
        </div>
    </nav>
    <!-- Contenido de la página -->
    <main>
        <!-- Este PHP se encarga de recoger los datos del formulario y procesar la reserva -->
        <?php
        // Inicia sesión si no se ha iniciado ya para mantener los datos del usuario
        session_start();
        // Datos de la conexión al servidor
        $servername = "localhost";
        $username = "ciclom";
        $password = "ciclom";
        $dbname = "smartoffice";
        // Crea la conexión
        $conn = mysqli_connect($servername, $username, $password, $dbname);
        // Comprueba la conexión
        if (!$conn) {
            // Si no se ha establecido correctamente la conexión te muestra el mensaje de error y  mata la conexión
            die("Conexión fallida: " . mysqli_connect_error());
        }
        // Recibe los datos del formulario HTML y los almacena en variables
        // El id del cliente lo toma de la variable $_SESSION['id_cliente'] que se almacena
        // cuando el usuario inicia sesión y que recupereamos al iniciar sesión 
        $id_cliente = $_SESSION['id_cliente'];
        $id_reserva = $_POST["id_reserva"];

        $sql = "SELECT id_cliente FROM reservas
                WHERE id = ?";

        $stmt = $conn->prepare($sql);
        $stmt->bind_param("s", $id_reserva);
        $stmt->execute();
        $result = $stmt->get_result();
        // Comprueba que haya resultados
        if (mysqli_num_rows($result) > 0) {
            // Si los hay, almacena el id de la oficina en la variable $id_oficina
                while($row  = mysqli_fetch_assoc($result)) {   
                    // Compara el id del cliente asociado a la reserva con el id del cliente actual
                    if ($row['id_cliente'] == $id_cliente) {
                        // La fecha coge la fecha del día en el que se realiza el pago
                        $fecha = date('Y-m-d');
                        $metodo = $_POST['metodo'];
                        // Prepara una sentencia para obtener el id de la oficina a partir del id de la reserva obtenido en el formulario
                        $sel2 = "SELECT id_oficina FROM reservas
                                WHERE id = ?";

                        // Prepara la consulta
                        $stmt = $conn->prepare($sel2);
                        // Establece el valor de ? como $id_reserva
                        $stmt->bind_param("s", $id_reserva);
                        // Ejecuta la consulta
                        $stmt->execute();
                        // Extrae los resultados
                        $result = $stmt->get_result();

                        // Comprueba que haya resultados
                        if (mysqli_num_rows($result) > 0) {
                            // Si los hay, almacena el id de la oficina en la variable $id_oficina
                            while($row  = mysqli_fetch_assoc($result)) {   
                                $id_oficina = $row["id_oficina"];
                                }
                        } else {
                            // Si no los hay muestra un mensaje de error
                            echo "Ninguna fila seleccionada";
                        }

                        // Procede a insertar los datos en la tabla reservas
                        // Primero crea la sentencia de inserción
                        $sql = "INSERT INTO pagos (id_cliente, id_oficina, id_reserva, fecha, metodo)
                        VALUES (?, ?, ?, ?, ?)";
                        // Luego prepara la sentencia
                        $stmt = $conn->prepare($sql);
                        // Junta los parametros ? con las variables correspondientes en el orden que aparecen
                        $stmt->bind_param("sssss", $id_cliente , $id_oficina, $id_reserva, $fecha, $metodo);
                        // Ejecuta la sentencia
                        $stmt->execute();
                        // Imprime por pantalla un mensaje de aviso que de que el pago se ha realizado correctamente
                        echo '<div class="aviso">Pago realizado correctamente.</div>';
                        // Botón que tira hacia atrás
                        echo '<button class="back-button" onclick="goBack()">Atrás</button>'; // Al hacer click ejecutará la función mencionada 
                    } else {
                        // Si no son iguales, muestra un mensaje de error
                        echo '<div class="aviso">No tiene ninguna reserva con ese número</div>';
                        // Botón que tira hacia atrás
                        echo '<button class="back-button" onclick="goBack()">Atrás</button>'; // Al hacer click ejecutará la función mencionada 
                    }
                }
            } else {
                // Si no los hay muestra un mensaje de error
                echo "No tiene ninguna reserva con ese número";
            }
            // Cierra la sentencia y la conexión
            $stmt->close();
            $conn->close();
        ?>
    </main>
    <!-- Aquí se describe la función que realiza el botón al hacer click en él -->
    <script>
        function goBack() {
            window.history.back(); // Mira el historial de la ventana y tira hacia detrás
        }
    </script>
    <!-- Footer con el copyright de la empresa -->
    <footer>
        <p>&copy; 2023 SmartOffice Rent</p>
    </footer>
</body>
</html>