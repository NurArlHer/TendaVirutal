<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

$servername = "localhost";
$username = "ciclom";
$password = 'ciclom';
$dbname = "usuarios";


// Create connection
$conn = mysqli_connect($servername, $username,$password,$dbname);

// Check connection
if (!$conn) {
  die("Connection failed: " . mysqli_connect_error());
}
// Insertar datos
$sql = "INSERT INTO usuarios (nombre, apellidos, email,fecha_nac)
VALUES ('Josep', 'Martínez', 'josmarsan10@alu.edu.gva.es','2003-01-13');";
$sql .= "INSERT INTO usuarios (nombre, apellidos, email,fecha_nac)
VALUES ('Alexandre', 'Fernández', 'alxferort@alu.edu.gva.es','2003-01-13');";
$sql .= "INSERT INTO usuarios (nombre, apellidos, email,fecha_nac)
VALUES ('Darío', 'Pérez', 'darpersor@alu.edu.gva.es','2003-01-13');";

if (mysqli_multi_query($conn, $sql)) {
  echo "Datos introducidos correctamente";
} else {
  echo "Error: " . $sql . "<br>" . mysqli_error($conn);
}

// Close connection
mysqli_close($conn);
?>