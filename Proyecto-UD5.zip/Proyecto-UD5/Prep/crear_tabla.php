<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

$servername = "localhost";
$username = "ciclom";
$password = 'ciclom';
$dbname = "usuarios";


// Create connection
$conn = mysqli_connect($servername, $username,$password,$dbname);

// Check connection
if (!$conn) {
  die("Connection failed: " . mysqli_connect_error());
}
// Create database
$sql = "CREATE TABLE usuarios (
    id INT(6) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    nombre VARCHAR(30) NOT NULL,
    apellidos VARCHAR(30) NOT NULL,
    email VARCHAR(50),
    fecha_nac DATE
    )";

if (mysqli_query($conn, $sql)) {
    echo "Tabla Usuarios creada correctamente";
  } else {
    echo "Error al crear la tabla: " . mysqli_error($conn);
  }
// Close connection
mysqli_close($conn);
?>