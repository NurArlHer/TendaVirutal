<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

$servername = "localhost";
$username = "ciclom";
$password = 'ciclom';
$dbname = "usuarios";


// Create connection
$conn = mysqli_connect($servername, $username,$password,$dbname);

// Check connection
if (!$conn) {
  die("Connection failed: " . mysqli_connect_error());
}

// prepare and bind
$stmt = $conn->prepare("INSERT INTO usuarios (nombre, apellidos, email,fecha_nac) VALUES (?, ?, ?, ?)");
$stmt->bind_param("ssss", $nombre, $apellido, $email, $fecha);


// set parameters and execute
$nombre = "Juan";
$apellido = "Pérez";
$email = "jperez@alu.edu.com";
$fecha = '1995-02-03';
$stmt->execute();

$nombre = "Lola";
$apellido = "García";
$email = "lgarcia@alu.edu.com";
$fecha = '1993-01-01';
$stmt->execute();

$nombre = "Maria";
$apellido = "Isabel";
$email = "misabel@alu.edu.com";
$fecha = '1998-02-03';
$stmt->execute();

echo "Datos introducidos correctamente";

$stmt->close();
$conn->close();
?>