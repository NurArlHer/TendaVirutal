<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

$servername = "localhost";
$username = "ciclom";
$password = 'ciclom';
$dbname = "usuarios";


// Create connection
$conn = mysqli_connect($servername, $username,$password,$dbname);

// Check connection
if (!$conn) {
  die("Connection failed: " . mysqli_connect_error());
}
// Create database
$sql = "INSERT INTO usuarios (nombre, apellidos, email, fecha_nac)
VALUES ('Núria', 'Arlandis', 'nurarlher@alu.edu.gva.es', '1997-07-07')";


if (mysqli_query($conn, $sql)) {
    echo "Datos insertados correctamente";
  } else {
    echo "Error: " . $sql . "<br>" . mysqli_error($conn);
  }

// Close connection
mysqli_close($conn);
?>