<?php
// Inicia la sesión para mantener el estado del usuario
session_start();

// Verificar que anteriormente se haya utilizado session_start() para iniciar sesión
// y que el usuario ha iniciado sesión como administrador
if (!isset($_SESSION["admin"]) || !$_SESSION["admin"]) {
        // Redirige a la página de inicio de sesión para el administrador
    // siempre y cuando el inicio sea incorrecto
    header("Location: login_admin.php");
    exit();
}
?>

<!-- A partir de aquí es el HTML que muestra la página con el estilo que sigue la web -->
<!DOCTYPE html>
<!-- Indica en la etiqueta html que el idioma es español -->
<html lang="es">
<head>
    <!-- Se indican los datos relevantes del estilo y metadatos de la página-->
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- Título de la página -->
    <title>Panel de Administración</title>
    <!-- Referencia del CSS con los estilos que sigue la página -->
    <link rel="stylesheet" href="style.css">
</head>
<!-- Aquí comienza el contenido de la página -->
<body>
    <!-- Header con el lema de la empresa y el logo -->
    <header>
        <div style="float: left;margin-left: 33%;">
            <h1 >Alquiler de Oficinas Flexibles</h1>
            <p>Encuentra tu espacio ideal</p>
        </div>
        <div style="float: right;margin-right: 20%;">
            <img src="logo2.png" alt="Logo">
        </div>
        
    </header>
    <!-- Navegador que lleva al resto de páginas de la web -->    
    <nav>
        <div class="nav-left">
            <a href="index.html">Inicio</a>
            <a href="registro.html">Registro</a>
            <a href="consultas.php">Consultas</a>
            <a href="inicio_sesion.html">Inicio de Sesión</a>
            <a href="encuesta.html">Encuesta Satisfacción</a>
        </div>
        <div class="nav-right">
            <a href="login_admin.php"><img src="settings.png" alt="Settings" style="max-width: 20px;"></a>
        </div>
    </nav>
    <!-- Contenido principal de la página -->
    <main>
        <!-- Bloque de saludo al administrador -->
        <div class="aviso">
            <h2>Bienvenido, Administrador</h2>
        </div>
        <br>
        <!-- Bloque que crea la base de datos utilizada -->
        <div class="aviso">
            <h3>CREAR BASE DE DATOS</h3>
            <a href="creacion.php" class="boton-registro">CREAR</a>
        </div>
        <br>
        <!-- Formulario de selección entre las opciones que puede realizar el administrador -->
        <h3>Selecciona una opción:</h3>
            <form method="post" action="admin_actions.php">
                <label for="usuarios">Ver Usuarios</label><br>
                <input type="radio" id="usuarios" name="seleccion" value="usuarios" required>
                
                <label for="reservas">Ver Reservas</label><br>
                <input type="radio" id="reservas" name="seleccion" value="reservas" required>
                
                <label for="pagos">Ver Pagos</label><br>
                <input type="radio" id="pagos" name="seleccion" value="pagos" required>
                
                <label for="pagos_pendientes">Ver Pagos Pendientes</label><br>
                <input type="radio" id="pagos_pendientes" name="seleccion" value="pagos_pendientes" required>

                <input type="submit" value="Ir">
            </form>
            <br>
            <!-- Bloque que cierra sesión -->
            <div class="aviso">
                <h3>CERRAR SESIÓN</h3>
                <a href="cerrar_sesion.php" class="boton-off">Cerrar Sesión</a>
            </div>
    </main>
    <!-- Footer con el copyright de la empresa -->
    <footer>
        <p>&copy; 2023 SmartOffice Rent</p>
    </footer>
</body>
</html>


<?php
    // Verificar que el usuario ha iniciado sesión como administrador
    if (!isset($_SESSION["admin"]) || !$_SESSION["admin"]) {
        header("Location: login_admin.php");
        exit();
    }

    // Procesar la selección del administrador
    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        $seleccion = $_POST["seleccion"];

        // Redirigir según la selección del administrador
        switch ($seleccion) {
            case "usuarios":
                header("Location: ver_usuarios.php");
                exit();
            case "reservas":
                header("Location: ver_reservas.php");
                exit();
            case "pagos":
                header("Location: ver_pagos.php");
                exit();
            case "pagos_pendientes":
                header("Location: ver_pagos_pendientes.php");
                exit();
        }
    }
?>