<!-- Inicio del HTML -->
<!DOCTYPE html>
<!-- Indica en la etiqueta html que el idioma es español -->
<html lang="es">
<head>
  <!-- Se indican los datos relevantes del estilo y metadatos de la página-->
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <!-- Título de la página -->
  <title>Menú de Consultas SmartOffice</title>
  <!-- Referencia del CSS con los estilos que sigue la página -->
  <link rel="stylesheet" href="style.css">
</head>
<!-- Aquí comienza el contenido de la página -->
<body>
  <!-- Header con el lema de la empresa y el logo -->
  <header>
    <div style="float: left;margin-left: 33%;">
        <h1 >Alquiler de Oficinas Flexibles</h1>
        <p>Encuentra tu espacio ideal</p>
    </div>
    <div style="float: right;margin-right: 20%;">
        <img src="logo2.png" alt="Logo">
    </div>
</header>
    <!-- Navegador que lleva a las otras páginas de la web -->
    <nav>
        <!-- Estos links quedarán alineados a la izquierda del navegador -->
        <div class="nav-left">
            <a href="index.html">Inicio</a> 
            <a href="registro.html">Registro</a>
            <a href="#">Consultas</a> <!-- lleva a # porque es esta misma página -->
            <a href="inicio_sesion.html">Inicio de Sesión</a>
            <a href="encuesta.html">Encuesta Satisfacción</a>
        </div>
        <!-- Estos links quedarán alineados a la derecha del navegador -->
        <div class="nav-right">
            <a href="login_admin.php"><img src="settings.png" alt="Settings" style="max-width: 20px;"></a>
        </div>
    </nav>
<!-- Contenido principal de la página -->
<main>
    <!-- Bloque con el contenido principal -->
    <div class="main-content">
        <!-- Texto que indica lo que puede realizar el usuario en esta página -->
        <h2>Realiza aquí tus consultas</h2>
        <p>Selecciona la consulta que quieras realizar para encontrar tu espacio ideal para cualquier tipo de acto.</p>
        <p>Consulta las oficinas disponibles, el tamaño o la ocupación de las mismas. SmartOffice se adapta a tus necesidades.</p>
        <img src="pexels-photo-277593.jpeg" alt="Consulta" style="max-width: 82%;border-radius: 0.7em;margin: 1vw;">
        <!--  Formulario que le pregunta que consulta quiere realizar -->
        <form method="post">
            <label for="consulta">Consulta:</label>
            <!-- Las diferentes consultas que pueden realizar -->
            <select id="consulta" name="consulta">
                <option value="disponibles">Oficinas Disponibles</option>
                <option value="ocupacion">Oficinas por Ocupación máxima</option>
                <option value="tamaño">Oficinas por Tamaño</option>
            </select>
            <!-- Botón para enviar la selección elegida -->
            <input type="submit" value="Consultar">
        </form>
        <br>
        <!-- Código PHP que te redirige a la página correspondiente según la elección -->
        <?php
            // Datos de la conexión al servidor
            $servername = "localhost";
            $username = "ciclom";
            $password = "ciclom";
            $dbname = "smartoffice";

            // Crea la conexión
            $conn = mysqli_connect($servername, $username, $password, $dbname);

            // Comprueba la conexión
            if (!$conn) {
                // Si no se ha establecido correctamente la conexión te muestra el mensaje de error
                // y mata la conexión
                die("Conexión fallida: " . mysqli_connect_error());
            } 

            // Recoge el valor de la consulta del formulario y lo guarda en la variable $consulta
            // y si este valor no está seleccionado o es nulo, le asigna el valor null (nulo)
            $consulta = $_POST["consulta"] ?? null;

            // Según el valor de $consulta te redirige a la página correspondiente
            if ($consulta == "disponibles") {
                header('Location: Untitled-1.php');
            } elseif ($consulta == "ocupacion") {
                header('Location: Untitled-3.php');
            } elseif ($consulta == "tamaño") {
                header('Location: Untitled-2.php');
            }

            // Cierra la conexión
            $conn->close();
        ?>
    </div>
</main>
<!-- Footer con el copyright de la empresa -->
<footer>
    <p>&copy; 2023 SmartOffice Rent</p>
</footer>
</body>
</html>