<?php
// Inicia la sesión para mantener el estado del usuario
session_start();

// Verificar que anteriormente se haya utilizado session_start() para iniciar sesión
// y que el usuario ha iniciado sesión como administrador
if (!isset($_SESSION["admin"]) || !$_SESSION["admin"]) {
    // Redirige a la página de inicio de sesión para el administrador
    // siempre y cuando el inicio sea incorrecto
    header("Location: login_admin.php");
    exit();
}

// Verifica que el método de envío HTTP del servidor es POST 
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Almacena los datos obtenidos en el formulario en una variable
    $seleccion = $_POST["seleccion"];

    // Según la opción marcada por el administrador, redirige a una página concreta
    switch ($seleccion) {
        case "usuarios":
            header("Location: ver_usuarios.php");
            exit();
        case "reservas":
            header("Location: ver_reservas.php");
            exit();
        case "pagos":
            header("Location: ver_pagos.php");
            exit();
        case "pagos_pendientes":
            header("Location: ver_pagos_pendientes.php");
            exit();
    }
}
?>
