<!-- Este PHP se encarga de recoger los datos de incio del administrador y comprobar que sean correctos -->
<?php
// Inicia la sesión si no está iniciada para mantener los datos del usuario
session_start();
// Comprueba que el método de envío del formulario sea POST
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Recoge los valores introducidos por el usuario en el formulario y los almacena en variables
    $usuario = $_POST["usuario"];
    $contrasena = $_POST["contrasena"];
    // Comprueba que el usuario sea admin y la contraseña también sea admin
    if ($usuario == "admin" && $contrasena == "admin") {
        // Establece que sí es una conexión de administrador
        $_SESSION["admin"] = true;
        // Redirige al panel de control del administrador
        header("Location: admin_panel.php");
        exit();
    } else {
        // Si no es el administador crea un mensaje de error
        $error = "ERROR: Solo el administrador puede acceder aquí.";
    }
}
?>

<!-- Inicio del HTML en caso de error -->
<!DOCTYPE html>
<!-- Indica en la etiqueta html que el idioma es español -->
<html lang="es">
<head>
    <!-- Se indican los datos relevantes del estilo y metadatos de la página -->
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- Título de la página -->
    <title>Inicio de Sesión - Administrador</title>
    <!-- Referencia del CSS con los estilos que sigue la página -->
    <link rel="stylesheet" href="style.css">
</head>
<!-- Aquí comienza el contenido de la página -->
<body>
    <header>
        <!-- Header con el lema de la empresa y el logo -->
        <div style="float: left;margin-left: 33%;">
            <h1 >Alquiler de Oficinas Flexibles</h1>
            <p>Encuentra tu espacio ideal</p>
        </div>
        <div style="float: right;margin-right: 20%;">
            <img src="logo2.png" alt="Logo">
        </div> 
    </header>
    <!-- Navegador que lleva a las otras páginas de la web -->
    <nav>
        <!-- Estos links quedarán alineados a la izquierda del navegador -->
        <div class="nav-left">
            <a href="index.html">Inicio</a>
            <a href="registro.html">Registro</a>
            <a href="consultas.php">Consultas</a>
            <a href="inicio_sesion.html">Inicio de Sesión</a>
            <a href="encuesta.html">Encuesta Satisfacción</a>
        </div>
        <!-- Estos links quedarán alineados a la derecha del navegador -->
        <div class="nav-right">
            <a href="login_admin.php"><img src="settings.png" alt="Settings" style="max-width: 20px;"></a>
        </div>
    </nav>
    <!-- Contenido principal de la página -->
    <main>
    <!-- Este PHP se encarga de comprobar si hay un error en el inicio de sesión del administrador -->
    <?php if (isset($error)) { ?>
        <!-- Si hay un error (la variable con el mensaje previamente creado), entonces saca un mensaje de alerta con el mensaje -->
        <script>
            alert("<?php echo $error; ?>");
        </script>
    <?php } ?>
    <!-- Formulario con método de envío POST que pide los datos de inicio del administrador -->
    <form method="post">
        <label for="usuario">Usuario:</label>
        <input type="text" id="usuario" name="usuario" required>
        <br>
        <label for="contrasena">Contraseña:</label>
        <input type="password" id="contrasena" name="contrasena" required>
        <br>
        <!-- Botón que envía los datos -->
        <input type="submit" value="Iniciar Sesión">
    </form>
    </main>
    <!-- Footer con el copyright de la empresa -->
    <footer>
        <p>&copy; 2023 SmartOffice Rent</p>
    </footer>
</body>
</html>