<!-- Este PHP se encarga de revisar si la sesión está iniciada para guardar el id del cliente -->
<?php
// Inicia la sesión si no está iniciada para mantener los datos de la sesión del cliente
session_start();
// Verifica si el usuario ha iniciado sesión y tiene guardado el id
if (!isset($_SESSION['id_cliente'])) {
    // Si no ha iniciado sesión, redirige a la página de inicio de sesión
    header("Location: inicio.php");
    exit();
}
?>

<!-- Inicio del HTML -->
<!DOCTYPE html>
<!-- Indica en la etiqueta html que el idioma es español -->
<html lang="es">
<head>
    <!-- Se indican los datos relevantes del estilo y metadatos de la página -->
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- Título de la página -->
    <title>Página de Inicio</title>
    <!-- Referencia del CSS con los estilos que sigue la página -->
    <link rel="stylesheet" href="style.css">
</head>
<!-- Aquí comienza el contenido de la página -->
<body>
    <!-- Header con el lema de la empresa y el logo -->
    <header>
        <div style="float: left;margin-left: 33%;">
            <h1 >Alquiler de Oficinas Flexibles</h1>
            <p>Encuentra tu espacio ideal</p>
        </div>
        <div style="float: right;margin-right: 15%;">
            <img src="logo2.png" alt="Logo">
        </div>
    </header>
    <!-- Navegador que lleva a las otras páginas de la web -->
    <nav>
        <!-- Estos links quedarán alineados a la izquierda del navegador -->
        <div class="nav-left">
            <a href="index.html">Inicio</a> 
            <a href="registro.html">Registro</a>
            <a href="consultas.php">Consultas</a> <!-- lleva a # porque es esta misma página -->
            <a href="inicio_sesion.html">Inicio de Sesión</a>
            <a href="encuesta.html">Encuesta Satisfacción</a>
        </div>
        <!-- Estos links quedarán alineados a la derecha del navegador -->
        <div class="nav-right">
            <a href="login_admin.php"><img src="settings.png" alt="Settings" style="max-width: 20px;"></a>
        </div>
    </nav>
    <!-- Contenido principal de la página -->
    <main>
        <!-- Sección que saluda al usuario -->
        <div class="aviso">
            <h2>Bienvenido, <?php 
            // Este PHP se encarga de obtener el nombre del usuario mediante el id de la sesión
            // Datos de la conexión al servidor
            $servername = "localhost";
            $username = "ciclom";
            $password = "ciclom";
            $dbname = "smartoffice";
            
            // Crea la conexión
            $conn = mysqli_connect($servername, $username, $password, $dbname);
            
            // Comprueba la conexión
            if (!$conn) {
                // Si no se ha establecido correctamente la conexión te muestra el mensaje de error y  mata la conexión
                die("Conexión fallida: " . mysqli_connect_error());
            } 

            // He utilizado sentencias preparadas para mayor seguridad
            // Primero prepara la consulta 
            $stmt_verificar = $conn->prepare("SELECT nombre FROM usuarios WHERE id = ?");
            // Establece el parámetro que va a ser la ? es el id del cliente
            $stmt_verificar->bind_param("s", $_SESSION['id_cliente']);
            // Ejecuta la consulta
            $stmt_verificar->execute();
            // Almacena el resultado
            $stmt_verificar->store_result();
            // Prepara para que el resultado se almacene en la variable $nombre
            $stmt_verificar->bind_result($nombre);
            // Obtiene los datos del resultado y los almacena en $nombre
            $stmt_verificar->fetch();
            // Muestra el nombre
            echo $nombre; 
            ?>!</h2>
            <p>Esta es tu página de inicio. Aquí puedes ver tus reservas.</p>

            <!-- Enlace que lleva a ver_reservas_user.php donde el usuario puede ver sus reservas -->
            <a href="ver_reservas_user.php" class="boton-registro">Ver Reservas</a>
        </div>
        <br>
        <!-- Sección que lleva a reservas para que el cliente reserve -->
        <div class="aviso">
            <h2>Realice una Reserva</h2>
            <p>Haga click en el siguiente botón para ir a Reservas.</p>
            <!-- Enlace que lleva a la página de reservas del usuario -->
            <a href="reservas_prov.php" class="boton-registro">Ir a Reservas</a>
        </div>
        <br>
        <!-- Sección que lleva al pago de las reservas del cliente -->
        <div class="aviso">
            <h2>Realice el pago de sus reservas</h2>
            <p>Haga click en el siguiente botón para ir a Pagos.</p>
            <!-- Enlace que lleva a la página de Pagos -->
            <a href="pagos.html" class="boton-registro">Ir a Pagos</a>
        </div>
        <br>
        <!-- Sección que lleva al cierre de sessión del usuario -->
        <div class="aviso">
            <h2>Cierre Sesión aquí</h2>
            <p>Haga click en el siguiente botón para cerrar sesión.</p>
            <!-- Enlace que lleva a la página de cerrar sesión -->
            <a href="cerrar_sesion.php" class="boton-off">Cerrar Sesión</a>
        </div>
    </main>
    <!-- Footer con el copyright de la empresa -->
    <footer>
        <p>&copy; 2023 SmartOffice Rent</p>
    </footer>
</body>
</html>