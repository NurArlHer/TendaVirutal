<!-- Inicio del HTML -->
<!DOCTYPE html>
    <!-- Indica en la etiqueta html que el idioma es español -->
    <html lang="es">
        <head>
            <!-- Se indican los datos relevantes del estilo y metadatos de la página-->
            <meta charset="UTF-8">
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
            <!-- Título de la página -->
            <title>Página de Cierre de Sesión</title>
            <!-- Referencia del CSS con los estilos que sigue la página -->
            <link rel="stylesheet" href="style.css">
        </head>
        <!-- Aquí comienza el contenido de la página -->
        <body>
            <!-- Header con el lema de la empresa y el logo -->
            <header>
                    <div style="float: left;margin-left: 33%;">
                        <h1 >Alquiler de Oficinas Flexibles</h1>
                        <p>Encuentra tu espacio ideal</p>
                    </div>
                    <div style="float: right;margin-right: 15%;">
                        <img src="logo2.png" alt="Logo">
                    </div>
                </header>
                <!-- Navegador que lleva a las otras páginas de la web -->
                <nav>
                    <!-- Estos links quedarán alineados a la izquierda del navegador -->
                    <div class="nav-left">
                        <a href="index.html">Inicio</a> 
                        <a href="registro.html">Registro</a>
                        <a href="consultas.php">Consultas</a>
                        <a href="inicio_sesion.html">Inicio de Sesión</a>
                        <a href="encuesta.html">Encuesta Satisfacción</a>
                    </div>
                    <!-- Estos links quedarán alineados a la derecha del navegador -->
                    <div class="nav-right">
                        <a href="login_admin.php"><img src="settings.png" alt="Settings" style="max-width: 20px;"></a>
                    </div>
                </nav>
            <!-- Contenido principal de la página -->
            <main>
                <!-- Bloque con un aviso de que se está cerrando sesión -->
                <div class="aviso">
                    <p>Cerrando sesión ...</p>
                    <p>Hasta luego!</p>
                </div>

                <!-- PHP que se encarga de cerrar sesión  -->
                <?php
                    // Inicia la sesión si no está iniciada
                    session_start();

                    // Limpia todas las variables de sesión
                    $_SESSION = array();

                    // Obtiene los parámetros de la cookie de sesión
                    $params = session_get_cookie_params();

                    // Borra la cookie de sesión si está presente
                    if (isset($_COOKIE[session_name()])) {
                        setcookie(
                            session_name(),
                            '',
                            time() - 42000,
                            $params['path'],
                            $params['domain'],
                            $params['secure'],
                            $params['httponly']
                        );
                    }

                    // Finalmente, destruye la sesión
                    session_destroy();
                ?>
        </main>
        <!-- Footer con el copyright de la empresa -->
        <footer>
            <p>&copy; 2023 SmartOffice Rent</p>
        </footer>
        </body>
    </html>