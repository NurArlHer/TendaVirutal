<!-- Inicio del HTML -->
<!DOCTYPE html>
<!-- Indica en la etiqueta html que el idioma es español -->
<html lang="es">
<head>
    <!-- Se indican los datos relevantes del estilo y metadatos de la página -->
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- Título de la página -->
    <title>Proceso Registro</title>
    <!-- Referencia del CSS con los estilos que sigue la página -->
    <link rel="stylesheet" href="style.css">
</head>
<!-- Aquí comienza el contenido de la página -->
<body>
    <!-- Header con el lema de la empresa y el logo -->
    <header>
        <div style="float: left;margin-left: 33%;">
            <h1 >Alquiler de Oficinas Flexibles</h1>
            <p>Encuentra tu espacio ideal</p>
        </div>
        <div style="float: right;margin-right: 15%;">
            <img src="logo2.png" alt="Logo">
        </div>
    </header>
    <!-- Navegador que lleva a las otras páginas de la web -->
    <nav>
        <!-- Estos links quedarán alineados a la izquierda del navegador -->
        <div class="nav-left">
            <a href="index.html">Inicio</a> <!-- lleva a # porque es esta misma página -->
            <a href="registro.html">Registro</a>
            <a href="consultas.php">Consultas</a>
            <a href="inicio_sesion.html">Inicio de Sesión</a>
            <a href="encuesta.html">Encuesta Satisfacción</a>
        </div>
        <!-- Estos links quedarán alineados a la derecha del navegador -->
        <div class="nav-right">
            <a href="login_admin.php"><img src="settings.png" alt="Settings" style="max-width: 20px;"></a>
        </div>
    </nav>
    <!-- Contenido principal de la página -->
    <main>
        <!-- Este php se encarga de comprobar que el usuario introducido no exista y si existe lo registra -->
        <?php
            // Datos de la conexión al servidor
            $servername = "localhost";
            $username = "ciclom";
            $password = "ciclom";
            $dbname = "smartoffice";
            // Crea la conexión
            $conn = mysqli_connect($servername, $username, $password, $dbname);
            // Comprueba la conexión
            if (!$conn) {
                // Si no se ha establecido correctamente la conexión te muestra el mensaje de error y  mata la conexión
                die("Conexión fallida: " . mysqli_connect_error());
            }
            // Verificar si el método de envio del formulario es POST
            if ($_SERVER["REQUEST_METHOD"] == "POST") {
                // Recibe los datos del formulario HTML y los almacena en variables
                $nombre = $_POST['nombre'];
                $apellidos = $_POST['apellidos'];
                $email = $_POST['email'];
                // Se podría realizar los siguiente para que la contraseña estuvise encriptada
                //$contrasena = password_hash($_POST['contrasena'], PASSWORD_DEFAULT); 
                $contrasena = $_POST['contrasena'];
                $confirmar_contrasena = $_POST['confirmar_contrasena'];

                // Comprueba que las contraseñas coincidan
                if ($contrasena != $confirmar_contrasena) {
                    echo '<h2 style="color:#333;">¡Inicio Sesión Incorrecto!</h2>';
                    echo '<div class="aviso">';
                    echo '<p>Las contraseñas no coinciden. Inténtalo de nuevo.</p>';
                    echo '<a href="registro.html" class="boton-registro">Volver al Registro</a>';
                    echo '</div>';
                } else {
                    // Consulta SQL para comprobar si el usuario existe en la base de datos
                    // Prepara una sentencia para comprobar si el usuario ya existe, por eso comprueba que el mail no se encuentre en la base de datos
                    $stmt_verificar = $conn->prepare("SELECT id FROM usuarios WHERE email = ?");
                    // Establece que ? es el email
                    $stmt_verificar->bind_param("s", $email);
                    // Ejecuta la sentencia
                    $stmt_verificar->execute();
                    // Almacena el resultado de la sentenica
                    $stmt_verificar->store_result();

                    // Comprueba que no haya resultados
                    if ($stmt_verificar->num_rows > 0) {
                        // Si los hay quiere decir que el usuario ya exite por lo que lo redirige a Inicio de sesión
                        echo '<h2 style="color:#333;">¡Inicio Sesión Incorrecto!</h2>';
                        echo '<div class="aviso">';
                        echo '<p>El usuario ya existe. Puedes iniciar sesión.</p>';
                        echo '<a href="inicio_sesión.html" class="boton-registro">Inicio Sesión</a>';
                        echo '</div>';
                    } else {
                        // Si no el usuario no existe y, por tanto, lo registra
                        // Prepara una sentencia para insertar los datos introducidos en el formulario
                        $stmt_insertar = $conn->prepare("INSERT INTO usuarios (nombre, apellidos, email, contrasenya) VALUES (?, ?, ?, ?)");
                        // Establece que las variables serán las ? en el orden indicado
                        $stmt_insertar->bind_param("ssss", $nombre, $apellidos, $email, $contrasena);
                        // Ejecuta la sentencia
                        $stmt_insertar->execute();
                        // Muestra un mensaje de confirmación y un botón para ir al inicio de la página
                        echo '<h2 style="color:#333;">¡Inicio Sesión Correcto!</h2>';
                        echo '<div class="aviso"><p>Usuario creado correctamente. Puedes iniciar sesión ahora.</p></div><br>';
                        echo '<a href="inicio_sesion.html" class="boton-registro">Ir a Inicio Sesión</a>';
                        // Cierra la sentencia preparada para que no se puedan introducir más
                        $stmt_insertar->close();
                    }
                    // Cerrar la conexión
                    $stmt_verificar->close();
                    $conn->close();
                }
            }
        ?>
    </main>
    <!-- Footer con el copyright de la empresa -->
    <footer>
        <p>&copy; 2023 SmartOffice Rent</p>
    </footer>
</body>
</html>