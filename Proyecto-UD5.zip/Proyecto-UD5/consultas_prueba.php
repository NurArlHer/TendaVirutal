<!-- Inicio del HTML -->
<!DOCTYPE html>
<!-- Indica en la etiqueta html que el idioma es español -->
<html lang="es">
<head>
    <!-- Se indican los datos relevantes del estilo y metadatos de la página -->
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- Título de la página -->
    <title>Oficinas Disponibles</title>
    <!-- Referencia del CSS con los estilos que sigue la página -->
    <link rel="stylesheet" href="style.css">
</head>
<!-- Aquí comienza el contenido de la página -->
<body>
    <!-- Header con el lema de la empresa y el logo -->
    <header>
        <div style="float: left;margin-left: 33%;">
            <h1 >Alquiler de Oficinas Flexibles</h1>
            <p>Encuentra tu espacio ideal</p>
        </div>
        <div style="float: right;margin-right: 15%;">
            <img src="logo2.png" alt="Logo">
        </div>
    </header>
    <!-- Navegador que lleva a las otras páginas de la web -->
    <nav>
        <!-- Estos links quedarán alineados a la izquierda del navegador -->
        <div class="nav-left">
            <a href="index.html">Inicio</a> 
            <a href="registro.html">Registro</a>
            <a href="#">Consultas</a> <!-- lleva a # porque es esta misma página -->
            <a href="inicio_sesion.html">Inicio de Sesión</a>
            <a href="encuesta.html">Encuesta Satisfacción</a>
        </div>
        <!-- Estos links quedarán alineados a la derecha del navegador -->
        <div class="nav-right">
            <a href="login_admin.php"><img src="settings.png" alt="Settings" style="max-width: 20px;"></a>
        </div>
    </nav>
    <!-- Contenido principal de la página -->
    <main>
        <div class="main-content">
            <h2>Realiza aquí tus consultas</h2>
            <p>Selecciona la consulta que quieras realizar para encontrar tu espacio ideal para cualquier tipo de acto.</p>
            <p>Consulta las oficinas disponibles, el tamaño o la ocupación de las mismas. SmartOffice se adapta a tus necesidades.</p>
            <img src="pexels-photo-277593.jpeg" alt="Consulta" style="max-width: 82%;border-radius: 0.7em;">
            <!-- Formulario que le pide la fecha y la hora a consultar al usuario con método de envío POST -->
            <form method="post">
                <!-- Pide los datos al usuario -->
                <label for="fecha">Fecha:</label>
                <input type="date" id="fecha" name="fecha" required>
                <br>
                <label for="hora">Hora:</label>
                <input type="time" id="hora" name="hora" required>
                <br>
                <input type="submit" value="Consultar Disponibilidad">
            </form>

            <!-- Este PHP de realizar la consulta de disponibilidad en la fecha seleccionada -->
            <!-- Este PHP de realizar la consulta de disponibilidad en la fecha seleccionada -->
            <?php

                // Datos de la conexión al servidor
                $servername = "localhost";
                $username = "ciclom";
                $password = "ciclom";
                $dbname = "smartoffice";

                // Crea la conexión
                $conn = mysqli_connect($servername, $username, $password, $dbname);

                // Comprueba la conexión
                if (!$conn) {
                    // Si no se ha establecido correctamente la conexión te muestra el mensaje de error y  mata la conexión
                    die("Conexión fallida: " . mysqli_connect_error());
                } 
                    $fecha = '2024-01-26';
                    $hora = '08:00:00';

                    // Para consultar la disponibilidad de las oficinas para dichos datos primero crea una consulta
                    $sql = "SELECT nombre, tamaño, ocupacion_maxima, planta, numero, edificio
                    FROM oficinas
                    WHERE id NOT IN (
                        SELECT DISTINCT id_oficina 
                        FROM reservas 
                        WHERE fecha = ? AND (
                            (hora_ini <= ? AND hora_fin >= ?) OR
                            (hora_ini <= ? AND hora_fin >= ?) OR
                            (hora_ini >= ? AND hora_fin <= ?)
                        )
                    )"; // Para comprobar que no esté en la franja horaria establecida

                    // Prepara la consulta
                    $stmt = $conn->prepare($sql);
                    // Vincular los parámetros de la consulta preparada con las variables indicadas
                    $stmt->bind_param("sssssss", $fecha, $hora, $hora, $hora, $hora, $hora, $hora);
                    // Ejecuta la consulta y compruba si ha tenido éxito la ejecución de la consulta
                    if (!$stmt->execute()) {
                    // Si ha fallado muestra un mensaje de error
                    echo "Falló la ejecución: (" . $stmt->errno . ") " . $stmt->error;
                    }

                    // De lo contrario, obtiene los resultados
                    $resultado = $stmt->get_result();

                    // Imprime los resultados en forma de tabla
                    echo '<br>';
                    echo "<table>
                    <tr>
                        <th>Nombre</th>
                        <th>Tamaño</th>
                        <th>Ocupación Máxima</th>
                        <th>Planta</th>
                        <th>Número</th>
                        <th>Edificio</th>
                    </tr>";

                    if (mysqli_num_rows($resultado) > 0) {
                    while ($row = mysqli_fetch_assoc($resultado)) {
                    echo "<tr>
                            <td>" . $row["nombre"] . "</td>
                            <td>" . $row["tamaño"] . "</td>
                            <td>" . $row["ocupacion_maxima"] . "</td>
                            <td>" . $row["planta"] . "</td>
                            <td>" . $row["numero"] . "</td>
                            <td>" . $row["edificio"] . "</td>
                        </tr>";
                    }
                    } else {
                    echo "<tr><td colspan='4'>Ninguna oficina seleccionada</td></tr>";
                    }

                    echo "</table>";


                    // Cerrar la conexión
                    $stmt->close();
                    $conn->close();
            ?>
        </div>
        <!-- Botón que tira hacia atrás -->
        <button class="back-button" onclick="goBack()">Atrás</button> <!-- Al hacer click ejecutará la función mencionada -->
        <!-- Aquí se describe la función que realiza el botón al hacer click en él -->
        <script>
            function goBack() {
                window.history.back(); // Mira el historial de la ventana y tira hacia detrás
            }
        </script>
    </main>
    <!-- Footer con el copyright de la empresa -->
    <footer>
        <p>&copy; 2023 SmartOffice Rent</p>
    </footer>
</body>
</html>