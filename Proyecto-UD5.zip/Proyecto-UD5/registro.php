<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Formulario de Registro de Cliente</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-image: url('pexels-photo-1939485.jpeg');
            color: #333;
            display: flex;
            flex-direction: column;
            min-height: 100vh;
        }

        html {
            height: 100%;
        }

        header {
            background-color: #333;
            color: #fff;
            text-align: center;
            padding: 1em;
        }

        nav {
    background-color: #333;
    overflow: hidden;
    display: flex;
    justify-content: space-between;
    align-items: center;
    padding: 0 1em;
}

.nav-left {
    display: flex;
}

.nav-left a {
    float: left;
    display: block;
    color: #f2f2f2;
    text-align: center;
    padding: 14px 16px;
    text-decoration: none;
}

.nav-left a:hover {
    background-color: #ddd;
    color: black;
}

.nav-right a {
    float: right;
    display: block;
    color: #f2f2f2;
    text-align: center;
    padding: 14px 16px;
    text-decoration: none;
}

.nav-right a:hover {
    background-color: #ddd;
    color: black;
}

        section {
            max-width: 75%;
            margin: 2em auto;
            padding: 1em;
            background-color: #fff;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }

        h1, h2 {
            color: #ffffff;
        }

        p {
            line-height: 1.6;
            color: #555;
        }

        footer {
            background-color: #333;
            color: #fff;
            text-align: center;
            padding: 1em;
            width: 100%;
            margin-top: auto;
        }

        .boton-registro {
            display: inline-block;
            padding: 10px 20px;
            font-size: 16px;
            text-align: center;
            text-decoration: none;
            background-color: #007BFF;
            color: #fff;
            border-radius: 5px;
            transition: background-color 0.3s;
        }

        .boton-registro:hover {
            background-color: #0056b3;
        }

        .banner {
            background: url('2.jpg') center/cover;
            color: #fff;
            text-align: center;
            padding: 4em 0;
        }

        .card {
            position: relative;
            background-size: cover;
            background-position: center;
            height: 200px;
            overflow: hidden;
            margin-bottom: 20px;
            cursor: pointer;
            border-radius: 0.7em;
        }

        .card:hover .card-content {
            transform: translateY(0);
        }

        .card-content {
            position: absolute;
            bottom: 0;
            left: 0;
            right: 0;
            padding: 20px;
            background: rgba(0, 0, 0, 0.473);
            color: #fff;
            border-radius: 0.7em;
            transform: translateY(100%);
            transition: transform 0.3s ease;
        }

        .middle {
            background-repeat: no-repeat;
            width: 60%;
            background-size: cover;
            border-radius: 1em;
        }

        header img {
            width: 7em;
            height: auto;
            vertical-align: middle;
        }

        /* Agrega este bloque de estilos al final de tu hoja de estilos actual */

main {
    text-align: center;
    margin: 2em 0;
}

form {
    display: grid;
    gap: 1em;
    max-width: 400px;
    margin: 0 auto;
    background-color: rgba(255, 255, 255, 0.9); /* Fondo blanco semitransparente */
    padding: 1em;
    border-radius: 10px; /* Bordes redondeados */
    box-shadow: 0 0 10px rgba(0, 0, 0, 0.1); /* Sombra ligera */
}

input {
    width: 100%;
    padding: 0.5em;
    box-sizing: border-box;
    margin-top: 0.5em;
    border: 1px solid #ccc; /* Borde gris claro */
    border-radius: 5px; /* Bordes redondeados */
}

label {
    font-weight: bold;
}

input[type="submit"] {
    background-color: #007BFF;
    color: #fff;
    cursor: pointer;
}

input[type="submit"]:hover {
    background-color: #0056b3;
}

    </style>
</head>
<body>

  <header>
    <div style="float: left;margin-left: 33%;">
        <h1 >Alquiler de Oficinas Flexibles</h1>
        <p>Encuentra tu espacio</p>
    </div>
    <div style="float: right;margin-right: 15%;">
        <img src="logo2.png" alt="Logo">
    </div>
    
</header>

<nav>
<div class="nav-right">
    <a href="index.html">Volver a Inicio</a>
</div>
</nav>

<!-- Contenido de la página -->
<main>
    <h2>Bienvenido a SmartOffice</h2>
    <p>Cumplimente el formulario para registrarse.</p>
    <p>¡Registrate y encuentra tu espacio ideal!</p>

    <form method="post">
        <label for="nombre">Nombre:</label>
        <input type="text" id="nombre" name="nombre" required>
        <br>

        <label for="apellidos">Apellidos:</label>
        <input type="text" id="apellidos" name="apellidos" required>
        <br>

        <label for="email">Correo Electrónico:</label>
        <input type="email" id="email" name="email" required>
        <br>

        <label for="contrasena">Contraseña:</label>
        <input type="password" id="contrasena" name="contrasena" required>
        <br>

        <input type="submit" value="Registrar">
        <?php
            error_reporting(E_ALL);
            ini_set('display_errors', 1);

            $servername = "localhost";
            $username = "ciclom";
            $password = "ciclom";
            $dbname = "smartoffice";

            // Crear conexión
            $conn = mysqli_connect($servername, $username, $password, $dbname);

            // Comprobar conexión
            if (!$conn) {
                die("Conexión fallida: " . mysqli_connect_error());
            }

            // Verificar si se ha enviado el formulario
            if ($_SERVER["REQUEST_METHOD"] == "POST") {
                // Recibir datos del formulario HTML
                $nombre = $_POST['nombre'];
                $apellidos = $_POST['apellidos'];
                $email = $_POST['email'];
                //$contrasena = password_hash($_POST['contrasena'], PASSWORD_DEFAULT);
                $contrasena = $_POST['contrasena'];

                // Verificar si el usuario ya existe
                $stmt_verificar = $conn->prepare("SELECT id FROM usuarios WHERE email = ?");
                $stmt_verificar->bind_param("s", $email);
                $stmt_verificar->execute();
                $stmt_verificar->store_result();

                if ($stmt_verificar->num_rows > 0) {
                    // El usuario ya existe, iniciar sesión o mostrar un mensaje de error
                    echo "El usuario ya existe. Puedes iniciar sesión.<br>";
                    echo '<a href="iniciar_sesion.php">Iniciar sesión</a>';
                } else {
                    // El usuario no existe, registrarlo
                    $stmt_insertar = $conn->prepare("INSERT INTO usuarios (nombre, apellidos, email, contrasenya) VALUES (?, ?, ?, ?)");
                    $stmt_insertar->bind_param("ssss", $nombre, $apellidos, $email, $contrasena);
                    $stmt_insertar->execute();

                    
                    session_start();
                    $_SESSION['id_cliente'] = $id_cliente;
                    echo "Usuario creado correctamente.<br>";
                    echo '<a href="index.html">Volver a Inicio</a>';
                    echo '<a href="reservas.php">Reservar</a>';
                    $stmt_insertar->close();
                }

                // Cerrar la conexión
                $stmt_verificar->close();
                $conn->close();
            }
        ?>
    </form>
</main>

<footer>
    <p>&copy; 2023 SmartOffice Rent</p>
</footer>

</body>
</html>
