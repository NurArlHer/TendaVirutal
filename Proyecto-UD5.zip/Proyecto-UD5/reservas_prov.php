<!-- Este PHP se encarga de revisar si la sesión está iniciada para guardar el id del cliente -->
<?php
    // Inicia la sesión si no está iniciada para mantener los datos de la sesión del cliente
    session_start();
    // Verifica si el usuario ha iniciado sesión y tiene guardado el id
    if (!isset($_SESSION['id_cliente'])) {
        // Si no ha iniciado sesión, redirige a la página de inicio de sesión
        header("Location: inicio_sesion.html");
        exit();
    }
?>

<!-- Inicio del HTML -->
<!DOCTYPE html>
<!-- Indica en la etiqueta html que el idioma es español -->
<html lang="es">
<head>
    <!-- Se indican los datos relevantes del estilo y metadatos de la página -->
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- Título de la página -->
    <title>Formulario de Reserva</title>
    <!-- Referencia del CSS con los estilos que sigue la página -->
    <link rel="stylesheet" href="style.css">
</head>
<!-- Aquí comienza el contenido de la página -->
<body>
    <!-- Header con el lema de la empresa y el logo -->
    <header>
        <div style="float: left;margin-left: 33%;">
            <h1 >Alquiler de Oficinas Flexibles</h1>
            <p>Encuentra tu espacio ideal</p>
        </div>
        <div style="float: right;margin-right: 15%;">
            <img src="logo2.png" alt="Logo">
        </div>
    </header>
    <!-- Navegador que lleva a las otras páginas de la web -->
    <nav>
        <!-- Estos links quedarán alineados a la izquierda del navegador -->
        <div class="nav-left">
            <a href="index.html">Inicio</a>
            <a href="registro.html">Registro</a>
            <a href="consultas.php">Consultas</a>
            <a href="inicio_sesion.html">Inicio de Sesión</a>
            <a href="encuesta.html">Encuesta Satisfacción</a>
        </div>
        <!-- Estos links quedarán alineados a la derecha del navegador -->
        <div class="nav-right">
            <a href="login_admin.php"><img src="settings.png" alt="Settings" style="max-width: 20px;"></a>
        </div>
    </nav>
    <!-- Contenido principal de la página -->
    <main>
        <!-- Mensaje de bienvenida al usuario -->
        <h2>Bienvenido, <?php 
            // Este PHP se encarga de obtener el nombre del usuario a través de la id guardada en $_SESSION['id_cliente']
            // Datos de la conexión al servidor 
            $servername = "localhost";
            $username = "ciclom";
            $password = "ciclom";
            $dbname = "smartoffice";
            // Crea la conexión
            $conn = mysqli_connect($servername, $username, $password, $dbname);
            // Comprueba la conexión
            if (!$conn) {
                // Si no se ha establecido correctamente la conexión te muestra el mensaje de error y  mata la conexión
                die("Conexión fallida: " . mysqli_connect_error());
            } 

            // He utilizado sentencias preparadas para mayor seguridad
            // Primero prepara la consulta 
            $stmt_verificar = $conn->prepare("SELECT nombre FROM usuarios WHERE id = ?");
            // Establece el parámetro que va a ser la ? es el id del cliente
            $stmt_verificar->bind_param("s", $_SESSION['id_cliente']);
            // Ejecuta la consulta
            $stmt_verificar->execute();
            // Almacena el resultado
            $stmt_verificar->store_result();
            // Prepara para que el resultado se almacene en la variable $nombre
            $stmt_verificar->bind_result($nombre);
            // Obtiene los datos del resultado y los almacena en $nombre
            $stmt_verificar->fetch();
            // Muestra el nombre
            echo $nombre; 
        ?>!</h2>

        <p>Realice sus reservas aquí!</p>
        <!-- Título del Formulario -->
        <h2 style="color: #333;">Formulario de Reserva</h2>
        <!-- Formulario de registro de una reserva con método de envío POST -->
        <form method="post">
            <!-- Pide los datos de la reserva al usuario -->
            <label for="fecha">Fecha:</label>
            <input type="date" id="fecha" name="fecha" required>
            <br>
            <label for="hora_ini">Hora de Inicio:</label>
            <input type="time" id="hora_ini" name="hora_ini" required>
            <br>
            <label for="hora_fin">Hora de Fin:</label>
            <input type="time" id="hora_fin" name="hora_fin" required>
            <br>
            <label for="oficina">Oficina:</label>
            <!-- Opciones de oficina -->
            <select id="oficina" name="oficina">
                <option value="Oficina A">Oficina A</option>
                <option value="Oficina B">Oficina B</option>
                <option value="Oficina C">Oficina C</option>
                <option value="Oficina X">Oficina X</option>
                <option value="Oficina Ejecutiva">Oficina Ejecutiva</option>
                <option value="Sala de Reuniones">Sala de Reuniones</option>
                <option value="Sala de Juntas">Sala de Juntas</option>
            </select>
            <br>
            <!-- Opciones del tipo de uso que se le va a dar -->
            <label for="tipo">Tipo de Uso:</label>
            <select id="tipo" name="tipo" required>
                <option value="personal">Personal</option>
                <option value="profesional">Profesional</option>
                <option value="recreativo">Recreativo</option>
                <option value="otro">Otro</option>
            </select>
            <br>
            <!-- Botón de envío de los datos -->
            <input type="submit" value="Realizar Reserva">
        </form>

        <!-- Este PHP se encarga de procesar la reserva y redirigirte a la página correspondiente -->
        <?php
            // Comprueba si el método de envío del formulario es POST
            if ($_SERVER["REQUEST_METHOD"] == "POST") {
                // Datos de la conexión al servidor
                $servername = "localhost";
                $username = "ciclom";
                $password = "ciclom";
                $dbname = "smartoffice";

                // Crea la conexión
                $conn = mysqli_connect($servername, $username, $password, $dbname);

                // Comprueba la conexión
                if (!$conn) {
                    // Si no se ha establecido correctamente la conexión te muestra el mensaje de error y  mata la conexión
                    die("Conexión fallida: " . mysqli_connect_error());
                } 
                // Comprueba que estén seleccionados la fecha y las horas de la franja horaria que quiere el cliente
                if(isset($_POST["fecha"]) && isset($_POST["hora_ini"]) && isset ($_POST["hora_fin"])){
                    // Obtiene los datos del formulario y los almacena en variables
                    $fecha = $_POST["fecha"];
                    $hora_ini = $_POST["hora_ini"];
                    $hora_fin = $_POST["hora_fin"];
                    $oficina = $_POST["oficina"];
                    $tipo = $_POST["tipo"];

                    // Para insertar los datos en reservas primero obtiene los datos de la oficina 
                    // a través del nombre seleccionado en el formulario
                    // Primero crea la consulta
                    $sel = "SELECT id, tamaño, ocupacion_maxima FROM oficinas
                        WHERE nombre = ?";
                    // Prepara la consulta
                    $stmt = $conn->prepare($sel);
                    // Establece que ? va a ser el valor de $oficina
                    $stmt->bind_param("s", $oficina);
                    // Ejecuta la consulta
                    $stmt->execute();
                    // Almacena el resultado
                    $result = $stmt->get_result();
                    // Comprueba que haya resultados
                    if (mysqli_num_rows($result) > 0) {
                        // Si los hay, recoge los valores de la oficina cuyo nombre es igual a $oficina en variables
                        while($row  = mysqli_fetch_assoc($result)) {   
                            $id_oficina= $row["id"];
                            $tamaño= $row["tamaño"];
                            $ocupacion_maxima= $row["ocupacion_maxima"];
                        }
                    }
                    // Verifica la disponibilidad de la oficina para la fecha y hora seleccionadas
                    // Para ello crea una consulta que compruebe la disponibilidad de dicha oficina 
                    $sql_disponibilidad= "SELECT id_oficina, hora_ini, hora_fin FROM reservas WHERE fecha = ?"; // Para comprobar que no esté en la franja horaria establecida ya que
                        // si esto ocurre quiere decir que ya está reservada 
                    // Prepara la sentencia
                    $stmt = $conn->prepare($sql_disponibilidad);
                    // Vincula las variables con los valores correspondientes en la sentencia preparada
                    $stmt->bind_param("s", $fecha);
                    
                    // Ejecuta la consulta
                    $stmt->execute();
                
                    // Almacena los resultados de la consulta
                    $stmt->store_result();

                                        // Si obtiene resultados la consulta quiere decir que la oficina está reservada en es rango hoario
                    // Por eso, comprueba los resultados
                    if ($stmt->num_rows > 0) {
                        // Vincula las variables de los resultados
                        $stmt->bind_result($id_oficina, $ini, $fin);
                    
                        // Itera sobre los resultados
                        while ($stmt->fetch()) {
                            if (($hora_ini >= $ini && $hora_ini < $fin) || ($hora_fin > $ini && $hora_fin <= $fin) || ($hora_ini == $ini && $hora_fin == $fin)) {
                                // La oficina no está disponible
                                // Redirige al usuario a la página de error_reserva.htmml
                                header('Location: error_reserva.html');
                            } else {
                                // Si no hay resultados es que no hay reserva y se encuentra disponible
                        // La oficina está disponible así que procesa la reserva
                        // Obtiene el id del cliente de los datos de la sesión
                        $id_cliente = $_SESSION['id_cliente'];
                        // Iniciamos el total a 0
                        $total = 0;
                        // Según ciertas condiciones que le ponemos va a ir calculando el total
                        // Para ello he utilizado tres bucles if

                        // El primero es en función del tamaño
                        if ($tamaño <= 150){
                            $total += 15;
                        } elseif ($tamaño > 150 && $tamaño < 250) {
                            $total += 20;
                        } else {
                            $total += 25;
                        }
                
                        // El segundo en función de la ocupación
                        if ($ocupacion_maxima < 5) {
                            $total += 0;
                        } elseif ($ocupacion_maxima > 5 && $ocupacion_maxima < 15) {
                            $total += 5;
                        } else {
                            $total += 10;
                        }
                
                        // El tercero en función del tipo de uso
                        if ($tipo == "personal") {
                            $total += 2;
                        } elseif ($tipo == "profesional") {
                            $total += 5;
                        } else {
                            $total += 20;
                        }
                        
                        // Convierte las horas en formato Unix para poder restarlas
                        $timestamp_ini = strtotime($hora_ini);
                        $timestamp_fin = strtotime($hora_fin);
                
                        // Calcula la diferencia en segundos entre las horas
                        $diferencia_segundos = $timestamp_fin - $timestamp_ini;
                
                        // Calcula el total de horas
                        $total_horas = $diferencia_segundos / 3600; // 3600 segundos en una hora
                
                        // Saca el total de la reserva en función de las horas
                        $total = $total * $total_horas;
                
                        // Para insertar todos los datos en la base de datos y para mayor seguridad 
                        // primero crea la consulta
                        $sql_insert_reserva = "INSERT INTO reservas (id_cliente, id_oficina, fecha, hora_ini, hora_fin, tipo, total)
                                            VALUES (?, ?, ?, ?, ?, ?, ?)";
                        // Después prepara la consulta
                        $stmt_insert = $conn->prepare($sql_insert_reserva);
                        // Vincula las variables con los valores correspondientes en la sentencia preparada
                        $stmt_insert->bind_param("sssssss", $id_cliente, $id_oficina, $fecha, $hora_ini, $hora_fin, $tipo, $total);
                        // Ejecuta la inserción y comprueba si ha tenido éxito
                        if ($stmt_insert->execute()) {
                            // Si todo ha sido correcto, redirige al usuario a la página de ok_reserva
                            header('Location: ok_reserva.html');
                        } else {
                            // Si por el contrario ha habido algún error, muestra un mensaje de error
                            echo "Error al procesar la reserva.";
                        }
                                            // Cierra las consultas y la conexión
                    $stmt->close();
                    $stmt_insert->close();
                    $conn->close();
                            }
                        }

                    } else {
                        // Si no hay resultados es que no hay reserva y se encuentra disponible
                        // La oficina está disponible así que procesa la reserva
                        // Obtiene el id del cliente de los datos de la sesión
                        $id_cliente = $_SESSION['id_cliente'];
                        // Iniciamos el total a 0
                        $total = 0;
                        // Según ciertas condiciones que le ponemos va a ir calculando el total
                        // Para ello he utilizado tres bucles if

                        // El primero es en función del tamaño
                        if ($tamaño <= 150){
                            $total += 15;
                        } elseif ($tamaño > 150 && $tamaño < 250) {
                            $total += 20;
                        } else {
                            $total += 25;
                        }
                
                        // El segundo en función de la ocupación
                        if ($ocupacion_maxima < 5) {
                            $total += 0;
                        } elseif ($ocupacion_maxima > 5 && $ocupacion_maxima < 15) {
                            $total += 5;
                        } else {
                            $total += 10;
                        }
                
                        // El tercero en función del tipo de uso
                        if ($tipo == "personal") {
                            $total += 2;
                        } elseif ($tipo == "profesional") {
                            $total += 5;
                        } else {
                            $total += 20;
                        }
                        
                        // Convierte las horas en formato Unix para poder restarlas
                        $timestamp_ini = strtotime($hora_ini);
                        $timestamp_fin = strtotime($hora_fin);
                
                        // Calcula la diferencia en segundos entre las horas
                        $diferencia_segundos = $timestamp_fin - $timestamp_ini;
                
                        // Calcula el total de horas
                        $total_horas = $diferencia_segundos / 3600; // 3600 segundos en una hora
                
                        // Saca el total de la reserva en función de las horas
                        $total = $total * $total_horas;
                
                        // Para insertar todos los datos en la base de datos y para mayor seguridad 
                        // primero crea la consulta
                        $sql_insert_reserva = "INSERT INTO reservas (id_cliente, id_oficina, fecha, hora_ini, hora_fin, tipo, total)
                                            VALUES (?, ?, ?, ?, ?, ?, ?)";
                        // Después prepara la consulta
                        $stmt_insert = $conn->prepare($sql_insert_reserva);
                        // Vincula las variables con los valores correspondientes en la sentencia preparada
                        $stmt_insert->bind_param("sssssss", $id_cliente, $id_oficina, $fecha, $hora_ini, $hora_fin, $tipo, $total);
                        // Ejecuta la inserción y comprueba si ha tenido éxito
                        if ($stmt_insert->execute()) {
                            // Si todo ha sido correcto, redirige al usuario a la página de ok_reserva
                            header('Location: ok_reserva.html');
                        } else {
                            // Si por el contrario ha habido algún error, muestra un mensaje de error
                            echo "Error al procesar la reserva.";
                        }
                                            // Cierra las consultas y la conexión
                    $stmt->close();
                    $stmt_insert->close();
                    $conn->close();
                    }

                }
            }
        ?>
    </main>
    <!-- Footer con el copyright de la empresa -->
    <footer>
        <p>&copy; 2023 SmartOffice Rent</p>
    </footer>
</body>
</html>