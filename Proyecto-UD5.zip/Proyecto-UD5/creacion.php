<!-- Inicio del HTML -->
<!DOCTYPE html>
<!-- Indica en la etiqueta html que el idioma es español -->
<html lang="es">
<head>
    <!-- Título de la página -->
    <title>SmartOffice Rent</title>
    <!-- Se indican los datos relevantes del estilo y metadatos de la página -->
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta charset="UTF-8">
    <!-- Referencia del CSS con los estilos que sigue la página -->
    <link rel="stylesheet" href="style.css">
</head>
<!-- Aquí comienza el contenido de la página -->
<body>
    <!-- Header con el lema de la empresa y el logo -->
    <header>
        <div style="float: left;margin-left: 33%;">
            <h1 >Alquiler de Oficinas Flexibles</h1>
            <p>Encuentra tu espacio ideal</p>
        </div>
        <div style="float: right;margin-right: 20%;">
            <img src="logo2.png" alt="Logo">
        </div>
    </header>
    <!-- Navegador que lleva a las otras páginas de la web -->
    <nav>
        <!-- Estos links quedarán alineados a la izquierda del navegador -->
        <div class="nav-left">
            <a href="index.html">Inicio</a>
            <a href="registro.html">Registro</a>
            <a href="consultas.php">Consultas</a>
            <a href="inicio_sesion.html">Inicio de Sesión</a>
            <a href="encuesta.html">Encuesta Satisfacción</a>
        </div>
        <!-- Estos links quedarán alineados a la derecha del navegador -->
        <div class="nav-right">
            <a href="login_admin.php"><img src="settings.png" alt="Settings" style="max-width: 20px;"></a>
        </div>
    </nav>
    <main>
<!-- PHP que se encarga de crear la base de datos y las tablas e inserta los datos -->
        <?php
        // Esta parte del código es para que en caso de que se produzca 
        // un error lo muestre por pantalla
        error_reporting(E_ALL);
        ini_set('display_errors', 1);

        // Datos de la conexión al servidor
        $servername = "localhost";
        $username = "ciclom"; // Cambiar por el usuario y contraseña de mysql
        $password = "ciclom";
        $dbname = "smartoffice";

        // Crea la conexión
        $conn = mysqli_connect($servername, $username, $password);

        // Comprueba la conexión
        if (!$conn) {
            // Si no se ha establecido correctamente la conexión te muestra el mensaje de error y  mata la conexión
            die("Conexión fallida: " . mysqli_connect_error());
        } 

        $sql = 'SHOW DATABASES LIKE "smartoffice"';
        $res = mysqli_query($conn, $sql);
        // Comprueba si la base de datos ya existe
        if (mysqli_num_rows($res) == 0) {

            // Crea la base de datos
            $sql = "CREATE DATABASE smartoffice";
            
            // Realiza el query que crea la base de datos
            if (mysqli_query($conn, $sql)){
                // Si se ejecuta con éxito muestra el mensaje de confirmación
                echo "Base de datos creada correctamente";
            } else {
                // En caso contrario muestra el mensaje de error con el error que se ha producido
                echo "Error al crear la base de datos: " . mysqli_error($conn);
            }

            // Cierra esta conexión
            mysqli_close($conn);

            // Para crear las tablas creamos otra conexión que conecte directamente
            // a la base de datos que acabamos de crear
            $conn = mysqli_connect($servername, $username, $password, $dbname);

            // Comprueba la conexión
            if (!$conn) {
                // Si no se ha establecido correctamente la conexión te muestra el mensaje de error
                // y mata la conexión
                die("Conexión fallida: " . mysqli_connect_error());
            } 

            // Guarda la sentencia que crea la tabla Usuarios en la variable $sql
            $sql = "CREATE TABLE usuarios (
                id INT(6) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
                nombre VARCHAR(30) NOT NULL,
                apellidos VARCHAR(70),
                email VARCHAR(50) NOT NULL,
                contrasenya VARCHAR(25) NOT NULL
            )";
            // Ejecuta la sentencia y comprueba el éxito de la ejecución
            if (mysqli_query($conn, $sql)){
                // Si se ejecuta con éxito muestra el mensaje de confirmación
                echo "Tabla <b>usuarios</b> creada correctamente<br>";
            } else {
                // En caso contrario muestra el mensaje de error con el error que se ha producido
                echo "Error creando la tabla <b>usuarios</b>: " . mysqli_error($conn);
            }
            // Guarda la sentencia que crea la tabla Oficinas en la variable $sql
            $sql = "CREATE TABLE oficinas (
                id INT(6) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
                nombre VARCHAR(30) NOT NULL,
                tamaño INT(6) NOT NULL,
                ocupacion_maxima INT(6)  NOT NULL,
                planta INT(6),
                numero INT(6),
                edificio VARCHAR(10)
            )";
            // Ejecuta la sentencia y comprueba el éxito de la ejecución
            if (mysqli_query($conn, $sql)){
                // Si se ejecuta con éxito muestra el mensaje de confirmación
                echo "Tabla <b>oficinas</b> creada correctamente<br>";
            } else {
                // En caso contrario muestra el mensaje de error con el error que se ha producido
                echo "Error creando la tabla <b>oficinas</b>: " . mysqli_error($conn);
            }
            // Guarda la sentencia que crea la tabla Reservas en la variable $sql
            $sql = "CREATE TABLE reservas (
                id INT(6) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
                id_cliente INT(6) UNSIGNED NOT NULL,
                id_oficina INT(6)  UNSIGNED NOT NULL,
                fecha DATE NOT NULL,
                hora_ini TIME NOT NULL,
                hora_fin TIME NOT NULL,
                tipo VARCHAR(30),
                total FLOAT NOT NULL,
                FOREIGN KEY (id_cliente) REFERENCES usuarios(id),
                FOREIGN KEY (id_oficina) REFERENCES oficinas(id)
            )";
            // Ejecuta la sentencia y comprueba el éxito de la ejecución
            if (mysqli_query($conn, $sql)){
                // Si se ejecuta con éxito muestra el mensaje de confirmación
                echo "Tabla <b>reservas</b> creada correctamente<br>";
            } else {
                // En caso contrario muestra el mensaje de error con el error que se ha producido
                echo "Error creando la tabla <b>reservas</b>: " . mysqli_error($conn);
            }
            // Guarda la sentencia que crea la tabla Pago en la variable $sql
            $sql = "CREATE TABLE pagos (
                id INT(6) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
                id_cliente INT(6)  UNSIGNED NOT NULL,
                id_oficina INT(6) UNSIGNED  NOT NULL,
                id_reserva INT(6) UNSIGNED  NOT NULL,
                fecha DATE NOT NULL,
                metodo VARCHAR(30),
                FOREIGN KEY (id_cliente) REFERENCES usuarios(id),
                FOREIGN KEY (id_oficina) REFERENCES oficinas(id),
                FOREIGN KEY (id_reserva) REFERENCES reservas(id)
            )";
            // Ejecuta la sentencia y comprueba el éxito de la ejecución
            if (mysqli_query($conn, $sql)){
                // Si se ejecuta con éxito muestra el mensaje de confirmación
                echo "Tabla <b>pagos</b> creada correctamente<br>";
            } else {
                // En caso contrario muestra el mensaje de error con el error que se ha producido
                echo "Error creando la tabla <b>pagos</b>: " . mysqli_error($conn);
            }

            // Inserta datos de prueba en la tabla Usuarios
            // He utilizado la inserción múltiple por eso a partir 
            // de la segunda sentencia se utiliza el . delante del =
            $sql = "INSERT INTO usuarios (nombre, apellidos, email, contrasenya)
            VALUES ('Nuria', 'Arlandis Hernández', 'n.arlandishdez@gmail.com', '12345');";
            $sql .= "INSERT INTO usuarios (nombre, apellidos, email, contrasenya)
            VALUES ('Pepe', 'Pérez Gil', 'p.perezgil@gmail.com', '12345');";
            $sql .= "INSERT INTO usuarios (nombre, apellidos, email, contrasenya)
            VALUES ('Lola', '', 'l.flores@gmail.com', '12345');";

            // Inserta datos de prueba en la tabla Oficinas
            $sql .= "INSERT INTO oficinas (nombre, tamaño, ocupacion_maxima, planta, numero, edificio)
            VALUES ('Oficina A', 200, 5, 1, 101, 'E0P1');";
            $sql .= "INSERT INTO oficinas (nombre, tamaño, ocupacion_maxima, planta, numero, edificio)
            VALUES ('Oficina B', 150, 3, 1, 102, 'E0P1');";
            $sql .= "INSERT INTO oficinas (nombre, tamaño, ocupacion_maxima, planta, numero, edificio)
            VALUES ('Sala de Reuniones', 80, 10, 1, 103, 'E0P1');";
            $sql .= "INSERT INTO oficinas (nombre, tamaño, ocupacion_maxima, planta, numero, edificio)
            VALUES ('Oficina Ejecutiva', 250, 2, 2, 201, 'E1P0');";
            $sql .= "INSERT INTO oficinas (nombre, tamaño, ocupacion_maxima, planta, numero, edificio)
            VALUES ('Oficina C', 180, 4, 2, 201, 'E0P1');";
            $sql .= "INSERT INTO oficinas (nombre, tamaño, ocupacion_maxima, planta, numero, edificio)
            VALUES ('Oficina X', 300, 6, 1, 101, 'E2P1');";
            $sql .= "INSERT INTO oficinas (nombre, tamaño, ocupacion_maxima, planta, numero, edificio)
            VALUES ('Sala de Juntas', 150, 12, 3, 301, 'E1P0');";

            // Inserta datos de prueba en la tabla Reservas
            $sql .= "INSERT INTO reservas (id_cliente, id_oficina, fecha, hora_ini, hora_fin, tipo, total)
            VALUES (1, 1, '2023-05-15', '10:00:00', '12:00:00', 'Profesional', 200);";
            $sql .= "INSERT INTO reservas (id_cliente, id_oficina, fecha, hora_ini, hora_fin, tipo, total)
            VALUES (2, 3, '2023-05-20', '14:00:00', '16:00:00', 'Recreativo', 300);";
            $sql .= "INSERT INTO reservas (id_cliente, id_oficina, fecha, hora_ini, hora_fin, tipo, total)
            VALUES (3, 2, '2023-06-01', '09:30:00', '11:30:00', 'Personal', 150);";
            $sql .= "INSERT INTO reservas (id_cliente, id_oficina, fecha, hora_ini, hora_fin, tipo, total)
            VALUES (1, 1, '2023-06-10', '12:30:00', '14:30:00', 'Profesional', 250);";
            $sql .= "INSERT INTO reservas (id_cliente, id_oficina, fecha, hora_ini, hora_fin, tipo, total)
            VALUES (2, 3, '2023-07-01', '08:00:00', '10:00:00', 'Otro', 100);";

            // Inserta datos de prueba en la tabla Pagos
            $sql .= "INSERT INTO pagos (id_cliente, id_oficina, id_reserva, fecha, metodo)
            VALUES (1, 1, 1, '2023-05-15', 'Tarjeta');";
            $sql .= "INSERT INTO pagos (id_cliente, id_oficina, id_reserva, fecha, metodo)
            VALUES (2, 3, 2, '2023-05-20', 'Transferencia');";
            $sql .= "INSERT INTO pagos (id_cliente, id_oficina, id_reserva, fecha, metodo)
            VALUES (3, 2, 3, '2023-06-01', 'PayPal');";
            $sql .= "INSERT INTO pagos (id_cliente, id_oficina, id_reserva, fecha, metodo)
            VALUES (1, 1, 4, '2023-06-10', 'Efectivo');";
            // Ejecutamos la sentencia y comprobamos si se realiza correctamente
            if (mysqli_multi_query($conn, $sql)){
                // Si se ejecuta con éxito muestra el mensaje de confirmación
                echo "Datos introducidos correctamente";
            } else {
                // En caso contrario muestra el mensaje de error con el error que se ha producido
                echo "Error al introducir los datos: " . mysqli_error($conn);
            }
            // Botón que tira hacia atrás 
            echo '<br><button class="back-button" onclick="goBack()">Atrás</button>'; // Al hacer click ejecutará la función mencionada
            // Esta sección está comentada porque es para comprobar los datos introducidos
            // realizando consultas sobre las tablas
            /*
            // Guarda la sentencia que consulta los datos (menos la contraseña) de los usuarios insertados
            $sel = "SELECT id, nombre, apellidos, email FROM usuarios";
            // Ejecuta la sentencia
            $result = mysqli_query($conn, $sel);
            // Comprueba si hay algún resultado
            if (mysqli_num_rows($result) > 0) {
                // Creamos una variable para almacenar el número de línea actual del bucle
                while($row  = mysqli_fetch_assoc($result)) {
                    // Si hay resultado los muestra por pantalla con el formato que le damos
                    echo "Id: " . $row["id"]. " - Nombre: " . $row["nombre"]. " - Apellidos: " . $row["apellidos"]. " - Email: " . $row["email"]. "<br>";
                }
            } else {
                // Si no imprime que no hay filas seleccionadas
                echo "Ninguna fila seleccionada";
            }

            // Guarda la sentencia que consulta los datos de las oficinas insertadas
            $sel = "SELECT id, nombre, tamaño, ocupacion_maxima,  planta,  numero, edificio FROM oficinas";
            // Ejecuta la sentencia
            $result = mysqli_query($conn, $sel);
            // Comprueba si hay algún resultado
            if (mysqli_num_rows($result) > 0) {
                // Creamos una variable para almacenar el número de línea actual del bucle
                while($row  = mysqli_fetch_assoc($result)) {
                    // Si hay resultado los muestra por pantalla con el formato que le damos
                    echo "Id: " . $row["id"]. " - Nombre: " . $row["nombre"]. " - Tamaño: " . $row["tamaño"]. 
                    " - Ocupación máxima: " . $row["ocupacion_maxima"]. " - Planta: " . $row["planta"]. " - Número: " .
                    $row["numero"]. " - Edificio: " . $row["edificio"]. "<br>";
                }
            } else {
                // Si no imprime que no hay filas seleccionadas
                echo "Ninguna fila seleccionada";
            }

            // Guarda la sentencia que consulta los datos de las reservas insertadas
            $sel = "SELECT id, id_cliente, id_oficina, fecha, hora_ini, hora_fin, tipo, total FROM reservas";
            // Ejecuta la sentencia
            $result = mysqli_query($conn, $sel);
            // Comprueba si hay algún resultado
            if (mysqli_num_rows($result) > 0) {
                // Creamos una variable para almacenar el número de línea actual del bucle
                while($row  = mysqli_fetch_assoc($result)) {
                    // Si hay resultado los muestra por pantalla con el formato que le damos
                    echo "Id: " . $row["id"]. " - Cliente: " . $row["id_cliente"]. " - Oficina: " . $row["id_oficina"]. 
                    " - Fecha: " . $row["fecha"]. " - Hora Inicio: " . $row["hora_ini"]. " - Hora Fin: " . $row["hora_fin"].
                    " - Tipo: " . $row["tipo"]. " - Total: " . $row["total"]. "<br>";
                }
            } else {
                // Si no imprime que no hay filas seleccionadas
                echo "Ninguna fila seleccionada";
            }

            // Guarda la sentencia que consulta los datos de los pagos insertados
            $sel = "SELECT id, id_cliente, id_oficina, id_reserva, fecha,  metodo FROM pagos";
            // Ejecuta la sentencia
            $result = mysqli_query($conn, $sel);
            if (mysqli_num_rows($result) > 0) {
                // Creamos una variable para almacenar el número de línea actual del bucle
                while($row  = mysqli_fetch_assoc($result)) {
                    // Si hay resultado los muestra por pantalla con el formato que le damos
                    echo "Id: " . $row["id"]. " - Cliente: " . $row["id_cliente"]. " - Oficina: " . $row["id_oficina"]. 
                    " - Reserva: " . $row["id_reserva"]. " - Fecha: " . $row["fecha"]. " - Método: " . $row["metodo"].
                    "<br>";
                }
            } else {
                // Si no imprime que no hay filas seleccionadas
                echo "Ninguna fila seleccionada";
            }*/
            } else {
                echo '<div class="aviso">La base de datos ya existe, no es necesario crearla.</div>';
                // Botón que tira hacia atrás 
                echo '<button class="back-button" onclick="goBack()">Atrás</button>'; // Al hacer click ejecutará la función mencionada

            }
        // Cierra la conexión
        mysqli_close($conn);
        ?>
    </main>
    <!-- Aquí se describe la función que realiza el botón al hacer click en él -->
    <script>
        function goBack() {
            window.history.back(); // Mira el historial de la ventana y tira hacia detrás
        }
    </script>
    <!-- Footer con el copyright de la empresa -->
    <footer>
        <p>&copy; 2023 SmartOffice Rent</p>
    </footer>
</body>
</html>